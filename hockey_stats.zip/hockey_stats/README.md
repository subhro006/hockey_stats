# Hockey Team Stats Scraper

## Setup Instructions

1. Install dependencies:
  
   pip install -r requirements.txt
